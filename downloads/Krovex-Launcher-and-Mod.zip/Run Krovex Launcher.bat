@echo off
rem Launches Krovex via the installed Java runtime (avoids Smart App Control
rem blocking the unsigned jpackage .exe).
cd /d "%~dp0Krovex Launcher"

where javaw.exe >nul 2>&1
if %errorlevel%==0 (
    start "" javaw.exe -jar "app\Krovex-Launcher.jar"
    exit /b 0
)

rem Fallback: common Adoptium install location
if exist "%ProgramFiles%\Eclipse Adoptium\jdk-21.0.13.10002-hotspot\bin\javaw.exe" (
    start "" "%ProgramFiles%\Eclipse Adoptium\jdk-21.0.13.10002-hotspot\bin\javaw.exe" -jar "app\Krovex-Launcher.jar"
    exit /b 0
)

echo Java was not found. Please install Java 21 from https://adoptium.net/
pause
